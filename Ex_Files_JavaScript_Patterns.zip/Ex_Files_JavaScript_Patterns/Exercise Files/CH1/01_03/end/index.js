const calc = () => {
    return 4 * 3;
}

let aNumber = calc();

console.log(aNumber);
