const calc = () => {
    return 4 * 3;
}

export default calc;
