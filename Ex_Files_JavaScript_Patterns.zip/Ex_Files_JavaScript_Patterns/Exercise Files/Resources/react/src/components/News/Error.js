import React from 'react';

const Error = () => (
  <div>
    <h1>There are no news, check your sources!!!</h1>
  </div>
);

export default Error;
